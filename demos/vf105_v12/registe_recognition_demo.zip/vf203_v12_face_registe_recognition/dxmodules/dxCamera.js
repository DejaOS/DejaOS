import { Facial } from './libvbar-m-dxfacial.so'; // Placeholder for native module import

const dxCamera = {};

// --- Constants & Enums ---


// Instantiate the native object immediately.
// Thanks to ES module caching, this will only run once.
const _native = new Facial();


// --- Public API ---

/**
 * Set camera preview enable/disable
 * @param {number} channel - Camera channel (0: RGB, 1: NIR)
 * @param {number} enable - Switch state (0: disable, 1: enable)
 */
dxCamera.capPreviewEnable = function (channel, enable) {
    _native.capPreviewEnable(channel, enable); // Throws on error
};

export default dxCamera; 