const dxDriver = {}

/*************************************Device Resource Enumeration*************************************/

/**
 * Device info
 */
dxDriver.DRIVER = {
    // Driver model
    MODEL:         "vf105"
}

/**
 * Display info
 */
dxDriver.DISPLAY = {
    // Display width
    WIDTH:         800,
    // Display height
    HEIGHT:         1280,
    // Display dpi
    DPI:         177,
    // Display rotation
    ROTATION:       0
}

/**
 * PWM channel
 */
dxDriver.PWM = {

    // White fill light
    WHITE_SUPPLEMENT_CHANNEL:         0,
    // Nir fill light
    NIR_SUPPLEMENT_CHANNEL:           1
}

/**
 * GPIO device pins
 */
dxDriver.GPIO = {

    // Relay
    RELAY0:         44,
}

/**
 * Channel communication
 */
dxDriver.CHANNEL = {

    // 485       
    UART_PATH:      "/dev/ttySLB2",

    // USBHID
	USBHID_PATH:    "/dev/hidg1",
}

/**
 * Camera related parameters
 */
dxDriver.CAPTURER = {
    // Camera image width
	RGB_WIDTH:  1280,
    // Camera image height
	RGB_HEIGHT:	800,
    // Camera device files
    RGB_PATH:  "/dev/video3",

    // Camera image width
	NIR_WIDTH:  800,
    // Camera image height
	NIR_HEIGHT:	600,
    // Camera device files
    NIR_PATH:  "/dev/video0"
}


/**
 * GPIO pin function enumeration
 */
dxDriver.GPIO_FUNC = {
	GPIO_FUNC_3:    0x03,  //0011, GPIO as function 3 / device 3
	GPIO_OUTPUT0:   0x04,  //0100, GPIO output low  level
	GPIO_OUTPUT1:   0x05  //0101, GPIO output high level
};


export default dxDriver