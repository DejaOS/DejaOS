import { Facial } from './libvbar-m-dxfacial.so'; // Placeholder for native module import

const dxCapcal = {};

// --- Constants & Enums ---


// Instantiate the native object immediately.
// Thanks to ES module caching, this will only run once.
const _native = new Facial();


// --- Public API ---

dxCapcal.init = function () {
    _native.initCapcal(); // Throws on error
};

dxCapcal.deinit = function () {
    _native.deinitCapcal();
};

dxCapcal.calculate = function (cnt) {
    return _native.calculateCapcal(cnt);
};

dxCapcal.getBox = function (cnt) {
    return _native.getBoxCapcal(cnt);
};

/**
 * Gets the native module instance.
 * @returns {object|null}
 */
dxCapcal.getNative = function () {
    return _native;
};

export default dxCapcal; 