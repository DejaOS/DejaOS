import { Facial } from './libvbar-m-dxfacial.so';
import log from './dxLogger.js'

const dxFacialBarcode = {};
const _native = new Facial();
let _callbacks = {};

/**
 * Initializes the barcode client. Must be called before any other operation.
 * @param {object} config - The configuration object.
 * @param {number} config.scanInterval - The interval between scans in milliseconds.
 * @param {number} config.scanTimeout - The timeout for a scan in milliseconds.
 * @param {number} config.roiX - The x-coordinate of the ROI.
 * @param {number} config.roiY - The y-coordinate of the ROI.
 * @example
 * dxFacialBarcode.init();
 */
dxFacialBarcode.init = function () {
    _native.initBarCode();
};

/**
 * Deinitializes the barcode client and releases resources.
 * @returns {void}
 * @example
 * dxFacialBarcode.deinit();
 */
dxFacialBarcode.deinit = function () {
    _native.deinitBarCode();
};

/**
 * Sets the callback function for barcode events.
 * @param {object} callbacks - The callback functions.
 * @param {function(object)} [callbacks.onEvent] - The callback function to handle barcode event.
 * @returns {void}
 * @example
 * dxFacialBarcode.setCallbacks({
 *   onEvent: function(event) {
 *     logger.info('Barcode event:', event);
 *   }
 * });
 */
dxFacialBarcode.setCallbacks = function (callbacks) {
    if (!callbacks || !callbacks.onEvent) {
        throw new Error('Callbacks must be an object with onEvent function');
    }
    _callbacks = callbacks;
};

/**
 * Sets the configuration for the barcode scanner.
 * @param {object} config - The configuration object.
 * @param {number} config.scanInterval - The interval between scans in milliseconds.
 * @param {number} config.scanTimeout - The timeout for a scan in milliseconds.
 * @param {number} config.roiX - The x-coordinate of the ROI.
 * @param {number} config.roiY - The y-coordinate of the ROI.
 */
dxFacialBarcode.setConfig = function (config) {
    _native.setConfigBarCode(config);
};

/**
 * Gets the configuration for the barcode scanner.
 * @returns {object} The configuration object.
 */
dxFacialBarcode.getConfig = function () {
    return _native.getConfigBarCode();
};

/**
 * Sets the status of the barcode scanner.
 * @param {boolean} status - The status of the barcode scanner.
 */
dxFacialBarcode.setStatus = function (status) {
    _native.setStatusBarCode(status);
};

/**
 * Processes events from the barcode event queue. Should be called periodically (e.g. in setInterval).
 * Handles barcode events and calls the registered callback function.
 * 
 * @example
 * setInterval(() => {
 *   dxFacialBarcode.loop();
 * }, 10); // Process events every 10ms
 */
dxFacialBarcode.loop = function () {
    try {
        let event = _native.getBarCodeEvent();
        if (event && _callbacks.onEvent) {
            _callbacks.onEvent(event);
        }
    } catch (e) {
        log.error('Error in barcode loop:', e);
    }
};

/**
 * Gets the native barcode client object.
 * @returns {Object|null} The native client object, or null if not initialized.
 */
dxFacialBarcode.getNative = function () {
    return _native;
};

export default dxFacialBarcode;