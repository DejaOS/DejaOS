xmlresource.exe ./
